The big differences of standalone Alternatives and Secret are:
No <Archers> root xml
the For= attribute do describle the archer that this alternative/secret belongs
Replace Al